exports.credentials = {
    host: "iron.cloudhosting.co.uk", 
    port: 587,
    user: 'quote@rubbertrackquote.co.uk', 
    pass: '1ljqX}^zRFQ{',
    domainName: "rubbertrackquote.co.uk",
    keySelector: "default",
    privateKey: "v=DKIM1; k=rsa; p=MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0VWtFDs3WjKimomTH9Crgu0Xv1uE8pFUzCuctmwayYW65JVHaefJWfXCQIm4vZlsa6O2myBC8ZMEwT6rRNbFuAqT9i/v/IyZwdCnGXo/60k6etY9GCbPMsU8KeBtKdNQv/rsnuiCbF19xrdG9by7tycE+xDYtDsl+f1bKkN7fFqeSVeVOqO5cd/UEucK1Po7Kcw3PLvt1Uu1DJVtF6y21Mf4c0C/ICoDZjYOET872sz50yplCb+fnLuR5dyXdyrXPiL0CquRpfKAha1XCXOGzV3hz3VGJN/ckhd5mfeOi1RvIufLvUg/Dmv+9FJCtmgRpNjT8scXqxYoPziAC4g+SQIDAQAB;",
    from: '"rubbertrackquote.co.uk" <quote@rubbertrackquote.co.uk>',
    to: "nvwebdevelopers@gmail.com",
    subject: "New quote request",
}


